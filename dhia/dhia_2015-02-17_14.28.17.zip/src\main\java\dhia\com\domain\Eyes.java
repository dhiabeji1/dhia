package dhia.com.domain;

public enum Eyes {

    brown, honey, green, hazel, lt_blue, dk_blue, amethist, gray
}
