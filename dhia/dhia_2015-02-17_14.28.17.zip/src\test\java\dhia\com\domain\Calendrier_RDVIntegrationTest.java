package dhia.com.domain;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Calendrier_RDV.class, transactional = false)
public class Calendrier_RDVIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
