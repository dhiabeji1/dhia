package dhia.com.domain;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Maps.class, transactional = false)
public class MapsIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
