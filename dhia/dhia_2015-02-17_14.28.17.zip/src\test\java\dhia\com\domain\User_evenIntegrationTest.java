package dhia.com.domain;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = User_even.class, transactional = false)
public class User_evenIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
