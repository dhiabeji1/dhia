package dhia.com.domain.users;

public enum Nationality {

    tunisienne, francaise, allemande, italienne
}
