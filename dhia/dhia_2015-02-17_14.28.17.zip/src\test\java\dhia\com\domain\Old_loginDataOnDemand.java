package dhia.com.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Old_login.class)
public class Old_loginDataOnDemand {
}
