package dhia.com.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Event_detail.class)
public class Event_detailDataOnDemand {
}
