package dhia.com.domain;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Doc_user.class, transactional = false)
public class Doc_userIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
