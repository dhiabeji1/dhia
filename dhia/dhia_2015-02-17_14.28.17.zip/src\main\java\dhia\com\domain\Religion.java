package dhia.com.domain;

public enum Religion {

    islam, christian, jewish
}
