package dhia.com;
import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { dhia.com.domain.Users.class })
public interface ServiceUsers {
}
