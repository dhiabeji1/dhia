package dhia.com.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Departement.class)
public class DepartementDataOnDemand {
}
