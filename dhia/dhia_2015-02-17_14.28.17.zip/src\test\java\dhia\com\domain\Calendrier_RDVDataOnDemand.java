package dhia.com.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Calendrier_RDV.class)
public class Calendrier_RDVDataOnDemand {
}
