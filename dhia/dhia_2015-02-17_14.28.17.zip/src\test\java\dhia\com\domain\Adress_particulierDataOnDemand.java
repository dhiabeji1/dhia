package dhia.com.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Adress_particulier.class)
public class Adress_particulierDataOnDemand {
}
