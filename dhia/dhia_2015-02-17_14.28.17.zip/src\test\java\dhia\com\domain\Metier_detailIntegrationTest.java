package dhia.com.domain;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Metier_detail.class, transactional = false)
public class Metier_detailIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
