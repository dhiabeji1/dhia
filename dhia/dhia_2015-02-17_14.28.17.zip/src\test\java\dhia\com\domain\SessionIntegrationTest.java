package dhia.com.domain;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Session.class, transactional = false)
public class SessionIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
