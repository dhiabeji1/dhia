package dhia.com.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Doc_user.class)
public class Doc_userDataOnDemand {
}
