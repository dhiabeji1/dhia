package dhia.com.domain;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Adress_user.class, transactional = false)
public class Adress_userIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
