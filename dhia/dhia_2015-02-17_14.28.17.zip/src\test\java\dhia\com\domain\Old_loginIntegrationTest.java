package dhia.com.domain;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Old_login.class, transactional = false)
public class Old_loginIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
