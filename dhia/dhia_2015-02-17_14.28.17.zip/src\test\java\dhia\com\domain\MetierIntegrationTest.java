package dhia.com.domain;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Metier.class, transactional = false)
public class MetierIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
