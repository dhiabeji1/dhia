package dhia.com.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = UseParrticulier.class)
public class UseParrticulierDataOnDemand {
}
