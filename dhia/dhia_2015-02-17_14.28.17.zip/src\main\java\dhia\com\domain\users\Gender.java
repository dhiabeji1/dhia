package dhia.com.domain.users;

public enum Gender {

    MALE, FEMALE
}
