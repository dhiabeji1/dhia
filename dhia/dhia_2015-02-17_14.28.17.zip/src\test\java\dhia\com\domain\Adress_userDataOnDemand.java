package dhia.com.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Adress_user.class)
public class Adress_userDataOnDemand {
}
