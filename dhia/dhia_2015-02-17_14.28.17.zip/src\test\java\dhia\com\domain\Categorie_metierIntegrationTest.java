package dhia.com.domain;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Categorie_metier.class, transactional = false)
public class Categorie_metierIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
